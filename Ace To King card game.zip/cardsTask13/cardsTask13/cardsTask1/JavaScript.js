﻿//counter that is used to determain the players turn.
var counter = 0;
//variable game that is used to set a new game each time.
var game;


// variable that contains the keys and values for the signs of the cards.
var Suits = {
    Clubs: 1,
    Diamonds: 2,
    Hearts: 3,
    Spades: 4,
}

//constractor that holds the number and sign of each card.
function Card(number, sign) {
    this.number = number;
    this.sign = sign;
}


//constractor that holds the player's name and an empty array for the cards. 
function Player(name) {
    this.cards = [];
    this.name = name;
}

//this function sorts the player's hand from least to greatest and also sorts the signs so they are not mixed together. 
function Extra7PointsSortedCards(Cards) {
    var SortCards = Cards.sort((a, b) => {
        if (a.number < b.number) return -1;
        if (a.number > b.number) return 1;
        return 0;
    });
    SortCards.sort((a, b) => (a.sign > b.sign) ? 1 : (a.sign < b.sign) ? -1 : 0);
    return SortCards;
}

//Game constractor sets:
//a new player for each of the players.
//an empty array for the cashier stack.
//an empty array for the trash stack.
//player 1 to be the active player (active player is the player that starts the game).
//the constractor contains a function called deal that creates a deck of cards (52)
// it also deals each player 13 cards.
//the constrator also has a shuffle function called "shuffle" that is used to shuffle the cashier stack.
function Game(player1, computer) {
    this.player1 = new Player(player1);
    this.computer = new Player(computer);

    this.cashierStack = [];
    this.trashStack = [];
    this.activePlayer = this.player1;

    // creates a deck of cards (52 cards)
    this.deal = function () {
        for (let i = 1; i <= 13; i++)
            for (let sign in Suits)
                this.cashierStack.push(new Card(i, sign));

        this.cashierStack.push(new Card('black','joker'));
        this.cashierStack.push(new Card('red', 'joker'));
        this.shuffle();


        // Deal 13 cards to each player
        for (let i = 0; i < 13; i++) {
            this.player1.cards.push(this.cashierStack.pop());
            this.computer.cards.push(this.cashierStack.pop());
        }

        /* Initialize the trash stack with one card from the top of the cashier stack*/
        this.trashStack.push(this.cashierStack.pop());
    }
    this.player1.cards = Extra7PointsSortedCards(this.player1.cards);
    this.computer.cards = Extra7PointsSortedCards(this.computer.cards);
  
  // Shuffle the cashier stack
    this.shuffle = function () {

        for (let i = this.cashierStack.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.cashierStack[i], this.cashierStack[j]] = [this.cashierStack[j], this.cashierStack[i]];
        }
    }    
}

//this function is used to render the cards to the screen(display).
//it displays:
// - player 1's cards aswell as player 2's cards.
// - Cashier stack
// - Trash stack.
// at the bottom of the function, we placed a few functions that are activated when the renderCards function is activated. 
function renderCards() {

    game.player1.cards = Extra7PointsSortedCards(game.player1.cards);
    game.computer.cards = Extra7PointsSortedCards(game.computer.cards);



    //displays player1's cards
    let player1Html = document.getElementById("player1-cards");
    player1Html.innerHTML = "";
    //loops through the length of player 1's cards and creates a div for each card (also gives each card the same class: "Card").
    //We then used the appendChild to push all of the new cards created into the player1-cards div.
    for (let i = 0; i < game.player1.cards.length; i++) {
        let card = game.player1.cards[i];
        let element = document.createElement('div');
        element.className = "card";
      

        element.style.backgroundImage = card.sign == 'joker'? `url(images/images/${card.number}_${card.sign}.png)` : `url(images/images/${card.number}_of_${card.sign}.png)`;

        player1Html.appendChild(element);

        //this onClick function activates the a function that takes the card thrown and places it in the trash.
        element.onclick = function () {
            SelectFromHandPlayer1(i);
        }
    };


    //displays player2's cards
    let computerHtml = document.getElementById("computer-cards");
    computerHtml.innerHTML = "";
    //loops through the length of player 2's cards and creates a div for each card (also gives each card the same class: "Card").
    //We then used the appendChild to push all of the new cards created into the player2-cards div.
    for (let i = 0; i < game.computer.cards.length; i++) {
        let card = game.computer.cards[i];
        let element = document.createElement('div');
        element.className = "card";
        element.style.backgroundImage = "url('images/images/back.png')";
        computerHtml.appendChild(element);

        //this onClick function activates the a function that takes the card thrown and places it in the trash.
        element.onclick = function () {
            SelectFromHandcomputer(i);
        }
    };


    //displays the cashier cards
    let deckHtml = document.getElementById("cashier-stack");
    deckHtml.innerHTML = "";
    //We wanted the Cashier stack to only display the back card image.
    let element = document.createElement('div');
    element.className = "card";
    element.style.backgroundImage = "url('images/images/back.png')";
    deckHtml.appendChild(element);

    //this onClick function activates a function that checks if the players won.
    //the onClick also activates a function that takes from the cashier and places it in the player's hand.
    element.onclick = function () {
        SelectFromcashier();
        game.player1.cards = Extra7PointsSortedCards(game.player1.cards);
        game.computer.cards = Extra7PointsSortedCards(game.computer.cards);
    }

    //displays the trash cards
    let trashHtml = document.getElementById("trash-stack");
    trashHtml.innerHTML = "";
    let card = game.trashStack[game.trashStack.length - 1];
    let element2 = document.createElement('div');
    element2.className = "card";
    element2.style.backgroundImage = card.sign == 'joker' ? `url(images/images/${card.number}_${card.sign}.png)` : `url(images/images/${card.number}_of_${card.sign}.png)`;
    trashHtml.appendChild(element2);

    //the onClick activates a function that takes from the trash and places it in the player's hand.
    element2.onclick = function () {
        SelectFromTrash();
    }

    //this activates the function that is used to show who's turn it is 
    playerTurn();

    //if the cashier card array is empty, activate a function that restocks the deck.
    if (game.cashierStack.length == 0) {
        RefrashcashierStack();
    }

    SaveGame();
};

//function that is used to show who's turn it is by outlining the border green.
function playerTurn() {
    if (game.activePlayer == game.player1) {
        document.getElementById("player1").style.border = "4px solid green";
        document.getElementById("player1").style.backgroundColor = "#c9f9c9";
        document.getElementById("computer").style.backgroundColor = "white";
        document.getElementById("computer").style.border = "inset";
    } else {
        document.getElementById("player1").style.border = "inset";
        document.getElementById("player1").style.backgroundColor = "white";
        document.getElementById("computer").style.backgroundColor = "#c9f9c9";
        document.getElementById("computer").style.border = "4px solid green";
    }
}

//takes the trash cards, shuffles them, and then places them back into the cashier cards. 
function RefrashcashierStack() {
    game.cashierStack = game.cashierStack.concat(game.trashStack);
    game.trashStack = [];
    game.shuffle();
}

//this function determains if the player has won.
//it checks to see if each player has 13 cards of the same sign. 
//once a player wins, the game will automatically restart. 
function CheckIfWon() {

    var player1firstCardSign = game.player1.cards[0].sign;
    var computerfirstCardSign = game.computer.cards[0].sign;

    var flag = 0;
    var flag2 = 0;

    for (let i = 0; i < game.player1.cards.length; i++) {
        if (player1firstCardSign == game.player1.cards[i].sign || game.player1.cards[i].sign=='joker') {
            flag++;
        }
    }
    if (flag == 13) {
        alert("player 1 has won! The game will now restart")
        startGame();
    }

    for (let i = 0; i < game.computer.cards.length; i++) {
        if (computerfirstCardSign == game.computer.cards[i].sign || game.computer.cards[i].sign == 'joker') {
            flag2++;
        }
    }
    if (flag2 == 13) {
        alert("computer has won!!  The game will now restart");
        startGame();
    }
}

//this function sets the begining of the game.
//it deals 13 cards to each player.
//it activates 2 functions - 1.creates a deck of cards (52 cards) , 2.shuffles the cashier cards
function startGame() {

    game = new Game('player1', 'computer');
    game.deal();
    
    game.player1.cards = Extra7PointsSortedCards(game.player1.cards);
    game.computer.cards = Extra7PointsSortedCards(game.computer.cards);

    document.getElementById("player1").style.border = "4px solid green";
   
    renderCards();
}

//player 1's actions (take card/remove card)
function SelectFromHandPlayer1(card) {

    if (game.activePlayer === game.player1) {

        if (counter != 0) {
            game.trashStack.push(game.player1.cards.splice(card, 1)[0]);
            game.activePlayer = game.computer;
            counter = 0;

            var x;
            setTimeout(function () {                
                 x = CompCountSuitsAndPushCard(game.computer.cards);
                renderCards();
            }, 2000);
            setTimeout(function () {
                CompTakeCard(game, x);
            }, 4000);
        }
    }
    //each turn, we will activate the funciton that checks whether the player has won.
    renderCards();
    setTimeout(CheckIfWon, 10000);
   // CheckIfWon();
}

//player 2's actions (take card/remove card)
function SelectFromHandcomputer(card) {

    if (game.activePlayer === game.computer) {

        if (counter != 0) {
            game.trashStack.push(game.computer.cards.splice(card, 1)[0]);
            game.activePlayer = game.player1;
            counter = 0;
        }
    }
    //each turn, we will activate the funciton that checks whether the player has won.
    setTimeout(CheckIfWon, 10000);
    //CheckIfWon();
    renderCards();   
}

//function that takes a card from the cashier stack and places it in a player's hand
function SelectFromcashier() {
  
    if (counter == 0) {
        if (game.activePlayer === game.player1) {
            game.player1.cards.push(game.cashierStack.pop());
            counter++;
            renderCards();
        }
    }  
}

//function that takes a card from the Trash stack and places it in a player's hand
function SelectFromTrash() {

    if (counter == 0) {
        if (game.activePlayer === game.player1) {
            game.activePlayer.cards.push(game.trashStack.pop());
            counter++;
            renderCards();
        }
    }  
   
}

//this will be used to activate the startGame funciton as soon as the page loads. 
//this also displays the rules of the game to the players at the begining of the game
window.onload = (event) => {
    loadGame();
    alert("Welcom to AceToKing!");
    alert("The green border around the name will indicate whose turn it is.");
    alert("Play fair! The first to reach a series of 13 cards that are the same sign wins the game!")
};


///////////////////////////////////////part 2//////////////////////////////////////////////////

function SaveGame() {

    // Save the game state to local storage
    localStorage.setItem('game', JSON.stringify(game));
    localStorage.setItem('counter', JSON.stringify(counter));
}

function loadGame() {
    // Get the game state from local storage
    let gameState = localStorage.getItem('game');
    let counterState = localStorage.getItem('counter');

    //this asks the player if they wish to reset their game or continue with the previous loaded game.
    if (gameState != null) {

        if (confirm("would you like to continue where you left off?")) {
            // Parse the game state from a string to a JavaScript object
            gameState = JSON.parse(gameState);

            // Load the game state
            loadGameState(gameState, counterState);
        } else {
            startGame();
            localStorage.clear(); //this deletes the local storage 
        }

    } else {
        startGame();
    }
}

function loadGameState(gameState, counterState) {
    game = gameState;
    counter = counterState;

    if (game.activePlayer.name == game.player1.name)
        game.player1 = game.activePlayer;
    else
        game.activePlayer = game.computer;

    renderCards();
}


function CompCountSuitsAndPushCard() {
  
    // Create a dict to store the suit counts
    var suitCounts = {
        'Clubs': 0,
        'Diamonds': 0,
        'Hearts': 0,
        'Spades': 0
    };
    //looping through all of player's 2 cards and updating the suitCounter
    for (let card of game.computer.cards) {
        suitCounts[card.sign]++;
    }
    //highest Suit 
    var MaxSign = { "suit": '', "value": 0 };

    //this checks to see which sign has the highest amounts of cards 
    for (let sign in suitCounts) {
        if (MaxSign.value < suitCounts[sign]) {
            MaxSign.value = suitCounts[sign];
            MaxSign.suit = sign;
        }
    }

    //this checks to see if the card is a joker. if it is it will take it. 
    if (game.trashStack[game.trashStack.length - 1].sign == 'joker') {
        game.computer.cards.push(game.trashStack.pop());
    }
    //this checks to see if when taking a card from the trash stack increases our max sign.
    //if it does, it will take from the trash stack and add it to the player's hand.
    //if not, it will take a card from the cashier stack. 
    else if (suitCounts[game.trashStack[game.trashStack.length - 1].sign] + 1 > MaxSign.value) {
        MaxSign.suit = game.trashStack[game.trashStack.length - 1].sign;
        game.computer.cards.push(game.trashStack.pop());

    } else {
        game.computer.cards.push(game.cashierStack.pop());
    }

    return MaxSign;
  
} 

function CompTakeCard(game, MaxSign) {
   
// Looping over the deck of the Computer cards.
    for (let i = 0; i < game.computer.cards.length; i++) {

        // this checks to see if the card that is found is of the same sign as the Maxsign.
        if (MaxSign.suit != game.computer.cards[i].sign) {

            // if the card is not the same sign as the MaxSign, it will add it to the trash stack. 
            game.trashStack.push(game.computer.cards[i]);
            game.computer.cards.splice(i, 1);
            break;
        }
    }
    //the active player will now be player 1
    game.activePlayer = game.player1;
    renderCards();
    setTimeout(CheckIfWon, 10000);
    // Return the suitCounts object

}
    



